export { OrderDetailPage as default } from './OrdersPage';
